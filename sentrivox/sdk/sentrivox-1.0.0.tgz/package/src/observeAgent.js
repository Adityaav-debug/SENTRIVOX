"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.observeAgent = observeAgent;
const axios_1 = __importDefault(require("axios"));
async function observeAgent(data) {
    try {
        await axios_1.default.post("http://localhost:5000/api/events", data);
        console.log("Telemetry sent to Sentrivox");
    }
    catch (error) {
        console.error("Failed to send telemetry", error);
    }
}
//# sourceMappingURL=observeAgent.js.map